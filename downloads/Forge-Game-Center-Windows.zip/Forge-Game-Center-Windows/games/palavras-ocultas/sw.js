const CACHE="forge-palavras-v7";
const ASSETS=["./","./index.html","./style.css","./manifest.webmanifest","./assets/palavras-ocultas-logo.jpg","./assets/icon-512.png"];
self.addEventListener("install",e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener("activate",e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener("fetch",e=>{if(e.request.method!=="GET")return;e.respondWith(caches.match(e.request).then(c=>c||fetch(e.request).then(r=>{var copy=r.clone();caches.open(CACHE).then(x=>x.put(e.request,copy));return r;}).catch(()=>caches.match("./index.html"))));});
